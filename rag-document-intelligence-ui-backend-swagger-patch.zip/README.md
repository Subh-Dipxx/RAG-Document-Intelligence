# RAG Document Intelligence — Frontend/Backend/Swagger patch

This is an overlay patch for the existing `rag-document-intelligence` monorepo.
It adds only the minimum UI and integration required for today's milestone and preserves the existing RAG implementation.

## Added

- React + Vite frontend under `frontend/`
- Document upload UI
- Document list UI
- Backend service health panel
- Swagger UI link
- Nginx reverse proxy from frontend to backend
- `frontend` Docker Compose service
- Explicit FastAPI OpenAPI/Swagger metadata
- `FRONTEND_PORT` in `.env` / `.env.example` if missing

## Apply

Copy this patch directory into the project root and run:

```bash
./APPLY_PATCH.sh
```

Then verify:

```bash
docker compose config --services
docker compose build frontend
docker compose up -d --build frontend
curl -I http://localhost:${FRONTEND_PORT:-3000}
curl -I http://localhost:8000/docs
```

Open the frontend on the configured frontend port and use the Swagger UI at the backend `/docs` endpoint.
